<html>
 <head>
  <title>PHP Sample Demo App</title>
 </head>
 <body>
 <?php echo '<p>Hello World - Working - Version 3</p>'; ?>
 <?php

	$txt2 = "Server IP Address";
	echo "<h2>" . $txt2 . "</h2>";

    $eip = file_get_contents('http://169.254.169.254/latest/meta-data/public-ipv4');
    echo $eip;
 ?>
 </body>
</html>
